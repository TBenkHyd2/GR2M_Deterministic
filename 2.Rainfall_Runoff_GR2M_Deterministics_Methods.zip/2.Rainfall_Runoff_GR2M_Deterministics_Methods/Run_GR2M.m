%RAINFALL-RUNOFF MODEL MODEL (GR2M WITH 3 PARAMETERS) BY TARIK BENKACI (1998-2017)
% and N. DECHEMI 
% OPTIMISATION METHODS: DETERMINISTICS METHODS WITH MANY ALGORITHMS
%in the Optimisation Models there is:  DETERMINISTICS METHODS
%    1 - --METHODES DETERMINISTES-- DETERMINISTICS_METHODS'),
%    2 - --METHODE PAR SOLVER--OPTIMISATION BY SOLVER'),
%    3 - --METHODE: DIRECT SEARCH_PATTERN SERACH--'),
%    4 - --METHODE STOCHASTIQUE SIMULANEALBND--SIMULANEALBND METHOD

%GR2M References
%2-Mouelhi, Safouane. 2003. �Vers Une Cha�ne Coh�rente de Mod�les Pluie-D�bit Conceptuels Globaux Aux Pas de Temps 
%Pluriannuel, Annuel, Mensuel et Journalier.� PhD thesis, Paris, ENGREF. 
%3-Mouelhi, S., C. Michel, C. Perrin, and V. Andr�assian (2006), Stepwise development of 
%a two-parameter monthly water balance model, J. Hydrol., 318, 200-214, doi:10.1016/j.jhydrol.2005.1006.1014.

clear all; 

Optim_Model
% thus the code execute optimisation Process to found best parameters of
% Conceptual GR2M model, with 3 parameters
%after optimisation the model displays and save the results in GR2M.xls results
%and RESULTS Text file
%Finally after optimisation the model can simulate new runoff values with
%GR2M_SIM
% Good Modelling



