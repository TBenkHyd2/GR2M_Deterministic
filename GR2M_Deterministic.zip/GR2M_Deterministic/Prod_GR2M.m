function [V,S1,S2,R1,R2,Qsim] = Prod_GR2M(x,V,P,E);
%  SUBROUTINE OF RAINFALL-RUNOFF MODEL MODEL (GR2M WITH 3 PARAMETERS) By  TARIK  BENKACI & N. Dechemi
%1-Mod�lisation pluie d�bit mensuelle et journali�re par les mod�les conceptuels et les syst�mes neuro-flous. Phd Thesis INA- ALGER
% the Model  uses VERSION OF MOUELHI
%2-Mouelhi, Safouane. 2003. PhD thesis, Paris, ENGREF. 
%3-Mouelhi, S., C. Michel, C. Perrin, and V. Andr�assian (2006) J. Hydrol., 318, 200-214
% FONCTION PRODUCTION 
%Reservoir sol-- Soil Store Production
%CALCUL DE LA FONCTION DE PRODUCTION
	WS=P/x(2);  
	if(WS>13);WS=13;end    
	S1=(V(1)+(x(2)*tanh(WS)))/(1.+V(1)/x(2)*tanh(WS));              
	P1=P+V(1)-S1 ;                 
      WS=E/x(2);         
	if(WS>13);WS=13;end    
	S2=S1*(1.-tanh(WS))/(1.+(1.-S1/x(2))*tanh(WS));                  

      V(1)=S2/((1+(S2/x(2))^3.)^(1./3.));         
	P2=S2-V(1) ; 
      P3=P1+P2;

% calculation (routing store):  
% MISE A JOUR DU RESERVOIR DE ROUTAGE R
% Updating store level OF reservoir R
      R1=V(2)+P3;
%  
      R2=x(1)*R1;
      % CALCUL OF SIMULATED RUNOFF-- CALCUL DU DEBIT SIMULE
      Qsim=R2.^2/(R2+x(3));
%Updatie Routing Store 
	V(2)=R2-Qsim;
