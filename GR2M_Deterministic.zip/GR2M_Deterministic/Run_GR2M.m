clear all; close all; clc;
%RAINFALL-RUNOFF MODEL MODEL (GR2M WITH 3 PARAMETERS) BY TARIK BENKACI & N. DECHEMI 
% For Optimisation of the GR2M Model we use Deterministic Search methods: 
% (1) Interior Point Algorithm, (2) Sequential Quadratic Programming: SQP methods solve a sequence of optimization subproblems, each of which optimizes a quadratic model of the objective subject to a linearization of the constraints.
% (3) Optimisation by Solver based on nonlinear least-squares algorithms like The Levenberg-Marquardt algorithm 
%     (not very efficient in Rainfall-Runoff modeling)
Optim_GR2M
% data=load('File_Data.txt'); % File of Data, do not change Name of this File, only copy and paste your Data
% P = data(:,1);  % First Vector : Rainfall in mm
% E = data(:,2);  % Second Vector : Evapotranspiration in mm
% Qobs=data(:,3); % Third Vector of Data  in m3/s
% param=load('parameters.txt'); % Paremters of Calibration
% Sup=param(1);  %Area of Baisn in km2

% Bounds & Initial of Parameters : in Files :   Bounds_Param.txt- Initial_Param.txt 
%Bounds=load('Bounds_Param.txt'); 
%lb=Bounds(1:3)'; Lower Bounds of Parameters X(1:3)
%ub=Bounds(4:6)'; Upper Bounds of Parameters X(1:3) 
% x0=load('Initial_Param.txt'); x0= x0' ; Unitial Values of Parameters X(1:3)
% thus the code execute optimisation Process to found best parameters of
% Conceptual GR2M model, with 3 parameters
%after optimisation the model displays and save the results in GR2M.xls results
%and RESULTS Text file
%Finally after optimisation the model can simulate new runoff values with
% GR2M matlab File. 




